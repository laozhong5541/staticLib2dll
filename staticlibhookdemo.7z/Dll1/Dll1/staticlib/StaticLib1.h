#pragma once

void fnStaticLib1();