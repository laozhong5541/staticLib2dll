﻿// StaticLib1.cpp : 定义静态库的函数。
//

#include "pch.h"
#include "framework.h"
#include "StaticLib1.h"

// TODO: 这是一个库函数示例
void fnStaticLib1()
{
	std::cout << "[StaticLib1.lib] Hello StaticLib1!" << std::endl;
}
